UPDATE `#__js_job_config` SET `configvalue` = '1.1.3' WHERE `configname` = 'version';
UPDATE `#__js_job_config` SET `configvalue` = '113' WHERE `configname` = 'versioncode';