UPDATE `#__js_job_config` SET `configvalue` = '1.1.6' WHERE `configname` = 'version';
UPDATE `#__js_job_config` SET `configvalue` = '116' WHERE `configname` = 'versioncode';
