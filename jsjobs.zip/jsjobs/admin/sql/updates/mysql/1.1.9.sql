UPDATE `#__js_job_config` SET `configvalue` = '1.1.9' WHERE `configname` = 'version';
UPDATE `#__js_job_config` SET `configvalue` = '119' WHERE `configname` = 'versioncode';
