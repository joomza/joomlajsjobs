UPDATE `#__js_job_config` SET `configvalue` = '1.2.0' WHERE `configname` = 'version';
UPDATE `#__js_job_config` SET `configvalue` = '120' WHERE `configname` = 'versioncode';
