UPDATE `#__js_job_config` SET `configvalue` = '1.2.6' WHERE `configname` = 'version';
UPDATE `#__js_job_config` SET `configvalue` = '126' WHERE `configname` = 'versioncode';
