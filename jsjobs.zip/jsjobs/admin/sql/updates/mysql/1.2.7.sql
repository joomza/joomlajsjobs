UPDATE `#__js_job_config` SET `configvalue` = '1.2.7' WHERE `configname` = 'version';
UPDATE `#__js_job_config` SET `configvalue` = '127' WHERE `configname` = 'versioncode';
