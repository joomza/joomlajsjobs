UPDATE `#__js_job_config` SET `configvalue` = '1.2.8' WHERE `configname` = 'version';
UPDATE `#__js_job_config` SET `configvalue` = '128' WHERE `configname` = 'versioncode';
