UPDATE `#__js_job_config` SET `configvalue` = '1.2.9' WHERE `configname` = 'version';
UPDATE `#__js_job_config` SET `configvalue` = '129' WHERE `configname` = 'versioncode';
