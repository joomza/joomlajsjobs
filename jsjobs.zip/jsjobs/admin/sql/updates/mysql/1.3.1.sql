UPDATE `#__js_job_config` SET `configvalue` = '1.3.1' WHERE `configname` = 'version';
UPDATE `#__js_job_config` SET `configvalue` = '131' WHERE `configname` = 'versioncode';
