UPDATE `#__js_job_config` SET `configvalue` = '1.3.2' WHERE `configname` = 'version';
UPDATE `#__js_job_config` SET `configvalue` = '132' WHERE `configname` = 'versioncode';
