UPDATE `#__js_job_config` SET `configvalue` = '1.3.3' WHERE `configname` = 'version';
UPDATE `#__js_job_config` SET `configvalue` = '133' WHERE `configname` = 'versioncode';
