UPDATE `#__js_job_config` SET `configvalue` = '1.3.4' WHERE `configname` = 'version';
UPDATE `#__js_job_config` SET `configvalue` = '134' WHERE `configname` = 'versioncode';
