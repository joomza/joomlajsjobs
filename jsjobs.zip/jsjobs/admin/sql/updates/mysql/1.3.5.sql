UPDATE `#__js_job_config` SET `configvalue` = '1.3.5' WHERE `configname` = 'version';
UPDATE `#__js_job_config` SET `configvalue` = '135' WHERE `configname` = 'versioncode';
