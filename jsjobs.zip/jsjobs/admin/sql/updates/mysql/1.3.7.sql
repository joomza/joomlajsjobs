UPDATE `#__js_job_config` SET `configvalue` = '1.3.7' WHERE `configname` = 'version';
UPDATE `#__js_job_config` SET `configvalue` = '137' WHERE `configname` = 'versioncode';
