<?php

/**
 * @Copyright Copyright (C) 2009-2010 Ahmad Bilal
 * @license GNU/GPL http://www.gnu.org/copyleft/gpl.html
 * Company:     Buruj Solutions
 + Contact:     https://www.burujsolutions.com , info@burujsolutions.com
 * Created on:  Nov 22, 2010
 ^
 + Project:     JS Jobs
 ^ 
 */

defined('_JEXEC') or die('Restricted access');

jimport('joomla.application.component.view');
jimport('joomla.html.pagination');

class JSJobsViewCategory extends JSView {

    function display($tpl = null) {
        require_once JPATH_COMPONENT_ADMINISTRATOR . '/views/common.php'; 
        if ($layoutName == 'categories') {        //categories
            JToolBarHelper::title(JText::_('Categories'));
            JToolBarHelper::addNew('category.add');
            JToolBarHelper::editList('category.edit');
            JToolBarHelper::cancel('category.cancel');
            JToolBarHelper::deleteList(JText::_('Are You Sure?'), 'category.deletecategoryandsubcategory', JText::_('Delete Cat').' & '.JText::_('Sub-Cat'));
            $sortby = JFactory::getApplication()->input->get('sortby','asc');
            $my_click = JFactory::getApplication()->input->get('my_click');
            if($my_click==1){
               $sortby = $this->getSortArg($sortby);
            }else{
                $sortby = $this->getJSModel('common')->checkSortByValue($sortby);
            }
            $js_sortby = JFactory::getApplication()->input->get('js_sortby');
            
            $form = 'com_jsjobs.category.list.';
            $searchname = $mainframe->getUserStateFromRequest($form . 'searchname', 'searchname', '', 'string');
            $searchstatus = $mainframe->getUserStateFromRequest($form . 'searchstatus', 'searchstatus', '', 'string');
            $result = $this->getJSModel('category')->getAllCategories($searchname, $searchstatus, $sortby, $js_sortby , $limitstart, $limit);
            $items = $result[0];
            $total = $result[1];
            $lists = $result[2];
            if ($total <= $limitstart)
                $limitstart = 0;
            $pagination = new JPagination($total, $limitstart, $limit);
            $this->pagination = $pagination;
            $this->lists = $lists;
            $this->js_sortby = $js_sortby;
            $this->sort = $sortby;
        }elseif ($layoutName == 'formcategory') {
            $c_id = "";
            $cid = JFactory::getApplication()->input->get('cid','');
            if(is_array($cid)) $c_id = $cid[0];

            if ($c_id == '') {
                $cids = JFactory::getApplication()->input->get('cid', array(0), 'post', 'array');
                $c_id = $cids[0];
            }
            if (is_numeric($c_id) == true AND $c_id != 0){
                $application = $this->getJSModel('category')->getCategorybyId($c_id);
                if(isset($application)) $this->application = $application;
            }
            if (isset($application->id))
                $isNew = false;
            $text = $isNew ? JText::_('Add') : JText::_('Edit');
            JToolBarHelper::title(JText::_('Category') . ': <small><small>[ ' . $text . ' ]</small></small>');
            JToolBarHelper::save('category.savecategory');
            if ($isNew)
                JToolBarHelper::cancel('category.cancel');
            else
                JToolBarHelper::cancel('category.cancel', 'Close');
        }
// layout end
        $this->config = $config;
        //$this->application = $application;
        if(isset($items)) $this->items = $items;
        $this->theme = $theme;
        $this->option = $option;
        $this->uid = $uid;
        $this->msg = $msg;
        $this->isjobsharing = $_client_auth_key;

        parent::display($tpl);
    }

    function getSortArg($sort) {
        if ($sort == 'asc')
            return "desc";
        else
            return "asc";
    }

}

?>
