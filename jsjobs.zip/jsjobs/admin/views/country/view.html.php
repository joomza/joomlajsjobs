<?php

/**
 * @Copyright Copyright (C) 2009-2010 Ahmad Bilal
 * @license GNU/GPL http://www.gnu.org/copyleft/gpl.html
 * Company:     Buruj Solutions
 + Contact:     https://www.burujsolutions.com , info@burujsolutions.com
 * Created on:  Nov 22, 2010
 ^
 + Project:     JS Jobs
 ^ 
 */

defined('_JEXEC') or die('Restricted access');

jimport('joomla.application.component.view');
jimport('joomla.html.pagination');

class JSJobsViewCountry extends JSView {

    function display($tpl = null) {
        require_once JPATH_COMPONENT_ADMINISTRATOR . '/views/common.php';
//        layout start
        if ($layoutName == 'formcountry') {          // countries
            $c_id = "";
            $cid = JFactory::getApplication()->input->get('cid','');
            if(is_array($cid)) $c_id = $cid[0];

            if ($c_id == '') {
                $cids = JFactory::getApplication()->input->get('cid', array(0), 'post', 'array');
                $c_id = $cids[0];
            }
            if (is_numeric($c_id) == true AND $c_id != 0)
                $country = $this->getJSModel('country')->getCountrybyId($c_id);
            if (isset($country->id))
                $isNew = false;
            $text = $isNew ? JText::_('Add') : JText::_('Edit');
            JToolBarHelper::title(JText::_('Country') . ': <small><small>[ ' . $text . ' ]</small></small>');
            if(isset($country)) $this->country = $country;
            JToolBarHelper::save('country.savecountry');
            if ($isNew)
                JToolBarHelper::cancel('country.cancel');
            else
                JToolBarHelper::cancel('country.cancel', 'Close');
        }elseif ($layoutName == 'countries') {          // countries
            JToolBarHelper::title(JText::_('Countries'));
            JToolBarHelper::addNew('country.editjobcountry');
            JToolBarHelper::editList('country.editjobcountry');
            JToolBarHelper::publishlist('country.publishcountries');
            JToolBarHelper::unpublishlist('country.unpublishcountries');
            JToolBarHelper::deleteList(JText::_('Are You Sure?'), 'country.deletecountry');
            $form = 'com_jsjobs.countries.list.';
            $searchname = $mainframe->getUserStateFromRequest($form . 'searchname', 'searchname', '', 'string');
            $searchstatus = $mainframe->getUserStateFromRequest($form . 'searchstatus', 'searchstatus', '', 'string');
            $hasstates = $mainframe->getUserStateFromRequest($form . 'hasstates', 'hasstates');
            $hascities = $mainframe->getUserStateFromRequest($form . 'hascities', 'hascities');

            $sortby = JFactory::getApplication()->input->get('sortby','asc');
            $my_click = JFactory::getApplication()->input->get('my_click');
            if($my_click==1){
               $sortby = $this->getSortArg($sortby);
            }else{
                $sortby = $this->getJSModel('common')->checkSortByValue($sortby);
            }
            $js_sortby = JFactory::getApplication()->input->get('js_sortby');

            $result = $this->getJSModel('country')->getAllCountries($searchname, $searchstatus , $hasstates, $hascities, $sortby, $js_sortby, $limitstart, $limit);
            $items = $result[0];
            $total = $result[1];
            $this->lists = $result[2];
            $this->js_sortby = $js_sortby;
            $this->sort = $sortby;
            
            if ($total <= $limitstart)
                $limitstart = 0;
            $pagination = new JPagination($total, $limitstart, $limit);
            $this->pagination = $pagination;
        }

        $this->config = $config;
        //$this->application = $application;
        if(isset($items)) $this->items = $items;
        $this->theme = $theme;
        $this->option = $option;
        $this->uid = $uid;
        $this->msg = $msg;
        $this->isjobsharing = $_client_auth_key;

        parent::display($tpl);
    }

    function getSortArg($sort) {
        if ($sort == 'asc')
            return "desc";
        else
            return "asc";
    }


}

?>
