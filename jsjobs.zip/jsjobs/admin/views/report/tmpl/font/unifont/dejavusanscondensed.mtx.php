<?php
/**
 * @Copyright Copyright (C)
 * @license GNU/GPL http://www.gnu.org/copyleft/gpl.html
 */
defined('_JEXEC') or die('Restricted access');

$name='DejaVuSansCondensed';
$type='TTF';
$desc=array (
  'Ascent' => 928,
  'Descent' => -236,
  'CapHeight' => 928,
  'Flags' => 4,
  'FontBBox' => '[-918 -415 1513 1167]',
  'ItalicAngle' => 0,
  'StemV' => 87,
  'MissingWidth' => 540,
);
$up=-63;
$ut=44;
$ttffile=JPATH_ADMINISTRATOR.'/components/com_jsjobs/views/report/tmpl/font/unifont/DejaVuSansCondensed.ttf';
$originalsize=643852;
$fontkey='dejavu';
?>