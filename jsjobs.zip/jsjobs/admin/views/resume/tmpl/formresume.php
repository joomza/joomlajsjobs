<?php

/**
 * @Copyright Copyright (C) 2009-2010 Ahmad Bilal
 * @license GNU/GPL http://www.gnu.org/copyleft/gpl.html
 * Company:     Buruj Solutions
 + Contact:     https://www.burujsolutions.com , info@burujsolutions.com
 * Created on:  Nov 22, 2010
 ^
 + Project:     JS Jobs
 ^ 
 */

defined('_JEXEC') or die('Restricted access');
$document = JFactory::getDocument();

$document->addStyleSheet(JURI::root() . 'components/com_jsjobs/css/token-input-jsjobs.css');
$document->addStyleSheet(JURI::root() . '/components/com_jsjobs/css/style.css');
require_once(JPATH_ROOT . '/components/com_jsjobs/css/style_color.php');
$document->addScript('../components/com_jsjobs/js/jquery.tokeninput.js');
$document->addScript(JURI::root() . 'components/com_jsjobs/js/multi-files-selector.js');
global $mainframe;
//JHTML::_('behavior.calendar');
JHTML::_('behavior.formvalidator');
?>

<div id="jsjobs-wrapper">
    <div id="jsjobs-menu">
        <?php include_once('components/com_jsjobs/views/menu.php'); ?>
    </div>    
    <div id="jsjobs-content">
        <div class="dashboard">
            <div id="jsjobs-wrapper-top-left">
                <div id="jsjobs-breadcrunbs">
                    <ul>
                        <li>
                            <a href="index.php?option=com_jsjobs&c=jsjobs&view=jsjobs&layout=controlpanel" title="<?php echo JText::_('Dashboard'); ?>">
                                <?php echo JText::_('Dashboard'); ?>
                            </a>
                        </li>
                        <li>
                            <a href="index.php?option=com_jsjobs&c=resume&view=resume&layout=<?php echo $this->callfrom?>" title="<?php echo JText::_('Resume'); ?>">
                                <?php echo JText::_('Resume'); ?>
                            </a>
                        </li>
                        <li>
                            <?php
                                echo JText::_('Add Resume');
                            ?>
                        </li>
                    </ul>
                    </ul>
                </div>
            </div>
            <div id="jsjobs-wrapper-top-right">
                <div id="jsjobs-config-btn">
                    <a href="index.php?option=com_jsjobs&c=configuration&view=configuration&layout=configurations" title="<?php echo JText::_('Configuration'); ?>">
                        <img alt="<?php echo JText::_('Configuration'); ?>" src="components/com_jsjobs/include/images/icon/config.png" />
                    </a>
                </div>
                <div id="jsjobs-help-btn" class="jsjobs-help-btn">
                    <a href="index.php?option=com_jsjobs&c=jsjobs&view=jsjobs&layout=help" title="<?php echo JText::_('Help'); ?>">
                        <img alt="<?php echo JText::_('Help'); ?>" src="components/com_jsjobs/include/images/help-page/help.png" />
                    </a>
                </div>
                <div id="jsjobs-vers-txt">
                    <?php echo JText::_("Version").' :'; ?>
                    <span class="jsjobs-ver">
                        <?php
                        $version1 = $this->getJSModel('configuration')->getConfigByFor('default');
                        $version = str_split($version1['version']);
                        $version = implode('', $version);
                        echo $version?>
                    </span>
                </div>
            </div>
        </div>
        <div id="jsjobs-head">
            <h1 class="jsjobs-head-text">
                <?php echo JText::_('Add Resume'); ?>
            </h1>
        </div>
        <div id="jsstadmin-data-wrp">
            <?php 
                require_once(JPATH_ROOT . '/components/com_jsjobs/views/resume/tmpl/formresume.php');
            ?>
        </div>
    </div>
</div>

<div id="jsjobs-footer">
    <table width="100%" style="table-layout:fixed;">
        <tr><td height="15"></td></tr>
        <tr>
            <td style="vertical-align:top;" align="center">
                <a class="img" target="_blank" href="https://www.joomsky.com"><img src="https://www.joomsky.com/logo/jsjobscrlogo.png"></a>
                <br>
                Copyright &copy; 2008 - <?php echo  date('Y') ?> ,
                <span id="themeanchor"> <a class="anchor"target="_blank" href="https://www.burujsolutions.com">Buruj Solutions </a></span>
            </td>
        </tr>
    </table>
</div>
