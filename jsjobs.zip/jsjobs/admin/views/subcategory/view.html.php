<?php

/**
 * @Copyright Copyright (C) 2009-2010 Ahmad Bilal
 * @license GNU/GPL http://www.gnu.org/copyleft/gpl.html
 * Company:     Buruj Solutions
 + Contact:     https://www.burujsolutions.com , info@burujsolutions.com
 * Created on:  Nov 22, 2010
 ^
 + Project:     JS Jobs
 ^ 
 */

defined('_JEXEC') or die('Restricted access');

jimport('joomla.application.component.view');
jimport('joomla.html.pagination');

class JSJobsViewSubcategory extends JSView {

    function display($tpl = null) {
        require_once JPATH_COMPONENT_ADMINISTRATOR . '/views/common.php';
//        layout start
        if ($layoutName == 'formsubcategory') {          // categories
            $c_id = "";
            $cid = JFactory::getApplication()->input->get('cid','');
            if(is_array($cid)) $c_id = $cid[0];


            if ($c_id == '') {
                $cids = JFactory::getApplication()->input->get('cid', array(0), 'post', 'array');
                $c_id = $cids[0];
            }
            $session = JFactory::getApplication()->getSession();
            $categoryid = $session->get('sub_categoryid');
            $subcategory = $this->getJSModel('subcategory')->getSubCategorybyId($c_id, $categoryid);

            if (isset($subcategory->id))
                $isNew = false;
            $text = $isNew ? JText::_('Add') : JText::_('Edit');
            JToolBarHelper::title(JText::_('Sub Category') . ': <small><small>[ ' . $text . ' ]</small></small>');
            $this->subcategory = $subcategory;
            $this->categoryid = $categoryid;
            JToolBarHelper::save('subcategory.savesubcategory');
            if ($isNew)
                JToolBarHelper::cancel('subcategory.cancelsubcategories');
            else
                JToolBarHelper::cancel('subcategory.cancelsubcategories', 'Close');
        }elseif ($layoutName == 'subcategories') {        //sub categories
            $categoryid = JFactory::getApplication()->input->get('cd', '');
            $session = JFactory::getApplication()->getSession();
            $session->set('sub_categoryid', $categoryid);
            $form = 'com_jsjobs.category.list.';
            $searchname = $mainframe->getUserStateFromRequest($form . 'searchname', 'searchname', '', 'string');
            $searchstatus = $mainframe->getUserStateFromRequest($form . 'searchstatus', 'searchstatus', '', 'string');            
            $result = $this->getJSModel('subcategory')->getSubCategories($categoryid, $searchname, $searchstatus, $limitstart, $limit);
            JToolBarHelper::title(JText::_('Sub Categories') . ' [' . $result[2]->cat_title . ']');
            JToolBarHelper::addNew('subcategory.editsubcategories');
            JToolBarHelper::editList('subcategory.editsubcategories');
            JToolBarHelper::deleteList(JText::_('Are You Sure?'), 'subcategory.removesubcategory');
            $items = $result[0];
            $total = $result[1];
            $this->lists=$result[3];
            if ($total <= $limitstart)
                $limitstart = 0;
            $pagination = new JPagination($total, $limitstart, $limit);
            $this->pagination = $pagination;
            $this->items = $items;
        }
//        layout end

        $this->config = $config;
        //$this->application = $application;
        if(isset($theme)) $this->theme = $theme;
        if(isset($option)) $this->option = $option;
        $this->uid = $uid;
        $this->msg = $msg;
        $this->isjobsharing = $_client_auth_key;

        parent::display($tpl);
    }

}

?>
