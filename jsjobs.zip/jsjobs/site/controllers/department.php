<?php

/**
 * @Copyright Copyright (C) 2009-2010 Ahmad Bilal
 * @license GNU/GPL http://www.gnu.org/copyleft/gpl.html
 * Company:     Buruj Solutions
 + Contact:     https://www.burujsolutions.com , info@burujsolutions.com
 * Created on:  Nov 22, 2010
 ^
 + Project:     JS Jobs
 ^ 
 */
 
defined('_JEXEC') or die('Restricted access');

jimport('joomla.application.component.controller');

class JSJobsControllerDepartment extends JSController {


    function __construct() {
        $app = JFactory::getApplication();
        $user = JFactory::getUser();
        if ($user->guest) { // redirect user if not login
            $link = 'index.php?option=com_user';
            $this->setRedirect($link);
        }
        parent::__construct();
    }

    function savedepartment() { //save department
        $jobsharing = $this->getModel('jobsharingsite', 'JSJobsModel');
        $uid = JFactory::getApplication()->input->get($uid, 'none', 'string');
        $Itemid = JFactory::getApplication()->input->get('Itemid');
        $department = $this->getmodel('Department', 'JSJobsModel');
        $return_value = $department->storeDepartment();
        if ($return_value == 1) {
            JSJOBSActionMessages::setMessage(SAVED, 'department','message');
        } else if ($return_value == 2) {
            JSJOBSActionMessages::setMessage(REQUIRED_FIELDS, 'department','error');
        } else {
            JSJOBSActionMessages::setMessage(SAVE_ERROR, 'department','error');
        }
        $link = 'index.php?option=com_jsjobs&c=department&view=department&layout=mydepartments&Itemid=' . $Itemid;
        $this->setRedirect(JRoute::_($link , false));
    }

    function deletedepartment() { //delete department
        JSession::checkToken('get') or die( 'Invalid Token' );
        $user = JFactory::getUser();
        $uid = $user->id;
        $Itemid = JFactory::getApplication()->input->get('Itemid');
        $common = $this->getmodel('Common', 'JSJobsModel');
        $departmentid = $common->parseId(JFactory::getApplication()->input->get('pd', ''));
        $department = $this->getmodel('Department', 'JSJobsModel');
        $return_value = $department->deleteDepartment($departmentid, $uid);
        $jobsharing = $this->getModel('jobsharingsite', 'JSJobsModel');
        if ($return_value == 1) {
            JSJOBSActionMessages::setMessage(DELETED, 'department','message');
        } elseif ($return_value == 2) {
            JSJOBSActionMessages::setMessage(DELETE_ERROR, 'department','error');
        } elseif ($return_value == 3) {
            JSJOBSActionMessages::setMessage(NOT_YOUR, 'department','error');
        } else {
            JSJOBSActionMessages::setMessage(DELETE_ERROR, 'department','error');
        }
        $link = 'index.php?option=com_jsjobs&c=department&view=department&layout=mydepartments&Itemid=' . $Itemid;
        $this->setRedirect(JRoute::_($link , false));
    }

    function listdepartments() {
        $val = JFactory::getApplication()->input->get('val');
        $depatments = $this->getmodel('Department', 'JSJobsModel');
        $returnvalue = $depatments->listDepartments($val);
        echo $returnvalue;
        JFactory::getApplication()->close();
    }

    function display($cachable = false, $urlparams = false) { // correct employer controller display function manually.
        $document = JFactory::getDocument();
        $viewName = JFactory::getApplication()->input->get('view', 'default');
        $layoutName = JFactory::getApplication()->input->get('layout', 'default');
        $viewType = $document->getType();
        $view = $this->getView($viewName, $viewType);
        $view->setLayout($layoutName);
        $view->display();
    }

}

?>
