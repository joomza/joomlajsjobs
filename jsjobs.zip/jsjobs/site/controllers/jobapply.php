<?php

/**
 * @Copyright Copyright (C) 2009-2010 Ahmad Bilal
 * @license GNU/GPL http://www.gnu.org/copyleft/gpl.html
 * Company:     Buruj Solutions
 + Contact:     https://www.burujsolutions.com , info@burujsolutions.com
 * Created on:  Nov 22, 2010
 ^
 + Project:     JS Jobs
 ^
 */

defined('_JEXEC') or die('Restricted access');

jimport('joomla.application.component.controller');

class JSJobsControllerJobApply extends JSController {


    function __construct() {
        $app = JFactory::getApplication();
        $user = JFactory::getUser();
        if ($user->guest) { // redirect user if not login
            $link = 'index.php?option=com_user';
            $this->setRedirect($link);
        }

        parent::__construct();
    }

    function applyjob() {
        $visitorapplyjob = $this->getModel('configurations', 'JSJobsModel')->getConfigValue('visitor_can_apply_to_job');
        if (!JFactory::getUser()->guest || $visitorapplyjob == '0') {
            $jobid = JFactory::getApplication()->input->get('jobid', false);
            $result = $this->getModel('Jobapply', 'JSJobsModel')->applyJob($jobid);
            $array[0] = 'popup';
            $array[1] = $result;
            print_r(json_encode($array));
        } else {
            $link = JRoute::_('index.php?option=com_jsjobs&c=jobapply&view=jobapply&layout=job_apply&bd=' . JFactory::getApplication()->input->get('jobid', false) . '&Itemid=' . JFactory::getApplication()->input->get('Itemid', false) ,false);
            $array[0] = 'redirect';
            $array[1] = $link;
            print_r(json_encode($array));
        }
        JFactory::getApplication()->close();
    }

    function jobapply() {
        $jobsharing = $this->getModel('jobsharingsite', 'JSJobsModel');
        $uid = JFactory::getApplication()->input->get($uid, 'none', 'string');
        $Itemid = JFactory::getApplication()->input->get('Itemid');
        $jobapply = $this->getmodel('Jobapply', 'JSJobsModel');
        $return_value = $jobapply->jobapply();
        if ($return_value == 1) {
            JSJOBSActionMessages::setMessage('Application successfully applied', 'jobapply','message');
            $link = 'index.php?option=com_jsjobs&c=jobapply&view=jobapply&layout=myappliedjobs&uid=' . $uid . '&Itemid=' . $Itemid;
        } else if ($return_value == 3) {
            JSJOBSActionMessages::setMessage('You already apply for this job', 'jobapply','warning');
            $link = 'index.php?option=com_jsjobs&c=jobapply&view=jobapply&layout=myappliedjobs&Itemid=' . $Itemid;
        } else if ($return_value == 10) {
            $textvar = JText::_('You can not apply for this job').'.'.JText::_('Your job apply limit exceeds');
            JSJOBSActionMessages::setMessage($textvar, 'jobapply','warning');
            $link = 'index.php?option=com_jsjobs&c=jobapply&view=jobapply&layout=myappliedjobs&Itemid=' . $Itemid;
        } else {
            JSJOBSActionMessages::setMessage('Error in applying for a job', 'jobapply','error');
            $link = 'index.php?option=com_jsjobs&c=jobapply&view=jobapply&layout=myappliedjobs&uid=' . $uid . '&Itemid=' . $Itemid;
        }
        $this->setRedirect(JRoute::_($link , false));
    }

    function jobapplyajax() {
        $uid = JFactory::getApplication()->input->get('uid', 'none', 'string');
        $jobapply = $this->getmodel('Jobapply', 'JSJobsModel');
        $return_value = $jobapply->jobapply();
        if ($return_value == 1) {
            $msg = JText::_('Application successfully applied');
        } else if ($return_value == 3) {
            $msg = JText::_('You already apply for this job');
        } else if ($return_value == 10) {
            $msg = JText::_('You can not apply for this job. Your job apply limit exceeds');
        } else {
            $msg = JText::_('Error in applying for a job');
        }
        echo $msg;
        JFactory::getApplication()->close();
    }

    function display($cachable = false, $urlparams = false) { // correct employer controller display function manually.
        $document = JFactory::getDocument();
        $viewName = JFactory::getApplication()->input->get('view', 'default');
        $layoutName = JFactory::getApplication()->input->get('layout', 'default');
        $viewType = $document->getType();
        $view = $this->getView($viewName, $viewType);
        $view->setLayout($layoutName);
        $view->display();
    }

}
?>


