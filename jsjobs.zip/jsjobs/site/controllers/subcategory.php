<?php

/**
 * @Copyright Copyright (C) 2009-2010 Ahmad Bilal
 * @license GNU/GPL http://www.gnu.org/copyleft/gpl.html
 * Company:     Buruj Solutions
 + Contact:     https://www.burujsolutions.com , info@burujsolutions.com
 * Created on:  Nov 22, 2010
 ^
 + Project:     JS Jobs
 ^ 
 */
 
defined('_JEXEC') or die('Restricted access');

jimport('joomla.application.component.controller');

class JSJobsControllerSubCategory extends JSController {


    function __construct() {
        $app = JFactory::getApplication();
        $user = JFactory::getUser();
        if ($user->guest) { // redirect user if not login
            $link = 'index.php?option=com_user';
            $this->setRedirect($link);
        }

        parent::__construct();
    }

    function listsubcategoriesforresume() {
        $val = JFactory::getApplication()->input->get('categoryid');
        if(!$val) $val = JFactory::getApplication()->input->get('val');
        $subcategory = $this->getmodel('Subcategory', 'JSJobsModel');
        $returnvalue = $subcategory->listSubCategoriesForResume($val);
        echo $returnvalue;
        JFactory::getApplication()->close();
    }

    function listsubcategories() {
        $val = JFactory::getApplication()->input->get('categoryid');
        if(!$val) $val = JFactory::getApplication()->input->get('val');
        $subcategory = $this->getmodel('Subcategory', 'JSJobsModel');
        $returnvalue = $subcategory->listSubCategories($val);
        echo $returnvalue;
        JFactory::getApplication()->close();
    }

    function listfiltersubcategories() {
        $val = JFactory::getApplication()->input->get('val');
        $subcategory = $this->getmodel('Subcategory', 'JSJobsModel');
        $returnvalue = $subcategory->listFilterSubCategories($val);
        echo $returnvalue;
        JFactory::getApplication()->close();
    }

    function listsubcategoriesforsearch() {
        $val = JFactory::getApplication()->input->get('val');
        $modulecall = JFactory::getApplication()->input->get('md');
        $subcategory = $this->getmodel('Subcategory', 'JSJobsModel');
        $returnvalue = $subcategory->listSubCategoriesForSearch($val);
        if ($modulecall) {
            if ($modulecall == 1) {
                //$return = JText::_('Sub Category') . "<br>" . $returnvalue;
                //$returnvalue = $return;
            }
        }
        echo $returnvalue;
        JFactory::getApplication()->close();
    }

    function subcategoriesforsearch() {
        $val = JFactory::getApplication()->input->get('val');
        $modulecall = JFactory::getApplication()->input->get('md');
        $subcategory = $this->getmodel('Subcategory', 'JSJobsModel');
        $returnvalue = $subcategory->SubCategoriesForSearch($val);
        if ($modulecall) {
            if ($modulecall == 1) {
                $return = JText::_('Sub Category') . "<br>" . $returnvalue;
                $returnvalue = $return;
            }
        }
        echo $returnvalue;
        JFactory::getApplication()->close();
    }

    function display($cachable = false, $urlparams = false) { // correct employer controller display function manually.
        $document = JFactory::getDocument();
        $viewName = JFactory::getApplication()->input->get('view', 'default');
        $layoutName = JFactory::getApplication()->input->get('layout', 'default');
        $viewType = $document->getType();
        $view = $this->getView($viewName, $viewType);
        $view->setLayout($layoutName);
        $view->display();
    }

}

?>
    
