<?php

/**
 * @Copyright Copyright (C) 2009-2010 Ahmad Bilal
 * @license GNU/GPL http://www.gnu.org/copyleft/gpl.html
 * Company:     Buruj Solutions
 + Contact:     https://www.burujsolutions.com , info@burujsolutions.com
 * Created on:  Nov 22, 2010
 ^
 + Project:     JS Jobs
 ^ 
 */
 
defined('_JEXEC') or die('Restricted access');

jimport('joomla.application.component.controller');

class JSJobsControllerUserRole extends JSController {


    function __construct() {
        $app = JFactory::getApplication();
        $user = JFactory::getUser();
        if ($user->guest) { // redirect user if not login
            $link = 'index.php?option=com_user';
            $this->setRedirect($link);
        }

        parent::__construct();
    }

    function savenewinjsjobs() { //save new in jsjobs
        $session = JFactory::getApplication()->getSession();
        $uid = JFactory::getApplication()->input->get($uid, 'none', 'string');
        $Itemid = JFactory::getApplication()->input->get('Itemid');
        $data = JFactory::getApplication()->input->post->getArray();

        $usertype = $data['usertype'];
        $userrole = $this->getmodel('Userrole', 'JSJobsModel');
        $return_value = $userrole->storeNewinJSJobs();
        $session = JFactory::getApplication()->getSession();
        $session->set('jsjobconfig_dft', '');
        $session->set('jsjobcur_usr', '');

        if ($usertype == 1) { // employer
            $link = 'index.php?option=com_jsjobs&c=jsjobs&view=employer&layout=controlpanel&Itemid=' . $Itemid;
        } elseif ($usertype == 2) {// job seeker
            $link = 'index.php?option=com_jsjobs&c=jsjobs&view=jobseeker&layout=controlpanel&Itemid=' . $Itemid;
        }

        if ($return_value == 1) {
            JSJOBSActionMessages::setMessage(SAVED, 'settings','message');
        } else {
            JSJOBSActionMessages::setMessage(SAVE_ERROR, 'settings','error');
        }
        $this->setRedirect(JRoute::_($link , false));
    }

    function checkuserdetail() {
        $val = JFactory::getApplication()->input->get('val');
        $for = JFactory::getApplication()->input->get('fr');
        $common = $this->getmodel('Common', 'JSJobsModel');
        $returnvalue = $common->checkUserDetail($val, $for);
        echo $returnvalue;
        JFactory::getApplication()->close();
    }

    function display($cachable = false, $urlparams = false) { // correct employer controller display function manually.
        $document = JFactory::getDocument();
        $viewName = JFactory::getApplication()->input->get('view', 'default');
        $layoutName = JFactory::getApplication()->input->get('layout', 'default');
        $viewType = $document->getType();
        $view = $this->getView($viewName, $viewType);
        $view->setLayout($layoutName);
        $view->display();
    }
}

?>
    
